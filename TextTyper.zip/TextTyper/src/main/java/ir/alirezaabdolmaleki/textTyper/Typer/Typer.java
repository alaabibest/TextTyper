package ir.alirezaabdolmaleki.textTyper.Typer;


import android.content.*;
import android.os.*;
import ir.alirezaabdolmaleki.textTyper.*;
import ir.alirezaabdolmaleki.*;

public class Typer extends TextTyper
{



	Context contex;
	int CRText =0;
	boolean continue_or_stop = true;
	public Typer(Context context)
	{
		super(context);
		contex =context;
	}
/*
	@Override
	public void typeText(String text, final int durationMS)
	{
		
		/*
		
	
	setText("kkkkk");
		//super.typeText(text, durationMS);
		
	}*/
}
