package ir.alirezaabdolmaleki.textTyper;

public class Fonts
{
	public static String PresianFont = "persian.ttf";
	public static String EnglishFont = "Dinomouse-Regular.otf";
	
	
}
