package ir.alirezaabdolmaleki.textTyper;

import android.app.*;
import android.content.*;

public class LibraryActivity extends Activity 
{

	public static void initialize(Context context) {
        
		ir.alirezaabdolmaleki.TextTyper.context = context;
    }}
